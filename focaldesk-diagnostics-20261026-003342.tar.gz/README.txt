FocalDesk diagnostic bundle
Generated: 2026-10-26T00:33:42.498132548+00:00
Schema: 1
Logs included: false

This bundle is bounded and automatically redacts common credential shapes, home-directory paths, usernames, and hostnames. Redaction is best effort. Review every file before sharing it publicly.

Included artifacts:
- graphics.txt
- services.txt
- session.txt
- system.txt
