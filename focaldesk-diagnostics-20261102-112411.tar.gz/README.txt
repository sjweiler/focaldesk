FocalDesk diagnostic bundle
Generated: 2026-11-02T11:24:11.533542942+00:00
Schema: 1
Logs included: false

This bundle is bounded and automatically redacts common credential shapes, home-directory paths, usernames, and hostnames. Redaction is best effort. Review every file before sharing it publicly.

Included artifacts:
- graphics.txt
- services.txt
- session.txt
- system.txt
